Challenge 1: Steganography
Useful Links:
https://en.wikipedia.org/wiki/JPEG_File_Interchange_Format#File_format_structure
https://users.cs.jmu.edu/buchhofp/forensics/formats/pkzip.html#localheader
https://linux.die.net/man/1/unzip
https://gist.github.com/briankip/8f8747a2488af827e3b4
https://en.wikipedia.org/wiki/Steganography

Hints:
https://unofficial-stemschool-challenge.github.io/Part1/hDWSLh6e3kNds9Q.html